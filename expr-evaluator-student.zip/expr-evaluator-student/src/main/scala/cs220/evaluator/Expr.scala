package cs220.evaluator

sealed abstract class Expr

/*
  TODO: Part 1: Implement expression types.
  This part of the assignment requires you to implement the expression
  types for each of the expressions that our evaluator will support.
  In particular:

  - Var       : variables
  - Number    : numbers
  - Add       : the addition expression (left + right)
  - Sub       : the subtraction expression (left - right)
  - Mul       : the multiplication expression (left * right)
  - Div       : the division expression (left / right)
  - Assign    : the assignment expression (v = expression)
  - Program   : the program expression (list of expression)
*/

// Case class for variables
case class Var(name: String) extends Expr{
  override def toString(): String = (s"$name")
}

// Case class for numbers
case class Number(value : Int) extends Expr{
  override def toString(): String = (s"$value")
}

// Case class for addition of two expressions
case class Add(left: Expr, right: Expr) extends Expr{
  override def toString(): String =
    (left.toString + " + " + right.toString)
}

// Cass class for substraction of two expressions
case class Sub(left: Expr, right: Expr) extends Expr{
  override def toString(): String =
    (left.toString + " - " + right.toString)
}

// Case class for multiplication of two expressions
case class Mul(left: Expr, right: Expr) extends Expr{
  override def toString(): String  =
    (left.toString + " * " + right.toString)
}

// Case class for division for two expressions
case class Div(left: Expr, right: Expr) extends Expr{
  override def toString(): String  =
    (left.toString + " / " + right.toString)
}

// Case class for assigning the value of an expression to a variable
case class Assign(left: Var, right: Expr) extends Expr{
  override def toString(): String =
    (left.toString + " = " + right.toString)
}

// Case class for a list of expressions
case class Program(exprs: List[Expr]) extends Expr{
  override def toString(): String = {
    var formatString = ""
    for(x <- exprs)
      formatString = formatString + x.toString + "\n"
    formatString.dropRight(1)
  }
}




