package cs220.evaluator

import org.scalatest.FunSuite

class ValueTestSuite extends FunSuite {

  test("The Value class exists") {
    // We simply assert that we can create a Value object. This ensures
    // that the student has created the Value class in the cs220 package.
    assert (Value != null)
  }

}