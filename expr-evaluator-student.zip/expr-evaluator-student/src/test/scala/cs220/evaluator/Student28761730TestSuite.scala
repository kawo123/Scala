package cs220.evaluator

import cs220.parser._
import org.scalatest.FunSuite

class Student28761730TestSuite extends FunSuite {

  test("Evaluation of subtraction expression with two variables") {
    val env = Environment.extend(Var("a"), Value(10))
    val env2 = env.extend(Var("b"), Value(15))
    val res = ExprParser.parse("a - b") match {
      case ExprParseSuccess(program) =>
        Evaluator.evalProgram(program, env2)
      case ExprParseFailure(message) => fail()
      case _ => fail()
    }
    // a - b = 10 - 15 = -5
    val EvaluationResult(v, e) = res
    assert(v == Value(-5))
    assert(e == env2)
  }

  test("Evaluation of multiplication expression with two variables") {
    val env = Environment.extend(Var("a"), Value(0.5))
    val env2 = env.extend(Var("b"), Value(30))
    val res = ExprParser.parse("a * b") match {
      case ExprParseSuccess(program) =>
        Evaluator.evalProgram(program, env2)
      case ExprParseFailure(message) => fail()
      case _ => fail()
    }
    // a * b = 0.5 * 30 = 15
    val EvaluationResult(v, e) = res
    assert(v == Value(15))
    assert(e == env2)
  }

  test("Evaluation of an addition expression involving two variables") {
    val env = Environment.extend(Var("x"), Value(39))
    val env2 = env.extend(Var("y"), Value(20))
    val res = ExprParser.parse("x + y") match {
      case ExprParseSuccess(program) =>
        Evaluator.evalProgram(program, env2)
      case ExprParseFailure(message) => fail()
      case _ => fail()
    }
    val EvaluationResult(v, e) = res
    // 39 + 10 == 49
    assert(v == Value(59))
    assert(e == env2)
  }

  test("Evaluation of division operation with two variables") {
    val env = Environment.extend(Var("a"), Value(15))
    val env2 = env.extend(Var("b"), Value(5))
    val res = ExprParser.parse("a / b") match {
      case ExprParseSuccess(program) =>
        Evaluator.evalProgram(program, env2)
      case ExprParseFailure(message) => fail()
      case _ => fail()
    }
    // a / b = 15 / 5 = 3
    val EvaluationResult(v, e) = res
    assert(v == Value(3))
    assert(e == env2)
  }

  test("Evaluation of 1st complex operation with multiple variables") {
    val env = Environment.extend(Var("a"), Value(15))
    val env2 = env.extend(Var("b"), Value(5))
    val env3 = env2.extend(Var("c"), Value(7))
    val env4 = env3.extend(Var("d"), Value(9))
    val res = ExprParser.parse("a / b + c * d") match {
      case ExprParseSuccess(program) =>
        Evaluator.evalProgram(program, env4)
      case ExprParseFailure(message) => fail()
      case _ => fail()
    }
    // a / b + c * d = 15 / 5 + 7 * 9  = 66
    val EvaluationResult(v, e) = res
    assert(v == Value(66))
    assert(e == env4)
  }

  test("Evaluation of 2nd complex operation with multiple variables") {
    val env = Environment.extend(Var("a"), Value(15))
    val env2 = env.extend(Var("b"), Value(5))
    val env3 = env2.extend(Var("c"), Value(-3))
    val env4 = env3.extend(Var("d"), Value(11))
    val res = ExprParser.parse("( a + b ) * c - d ") match {
      case ExprParseSuccess(program) =>
        Evaluator.evalProgram(program, env4)
      case ExprParseFailure(message) => fail()
      case _ => fail()
    }
    // ( 15 + 5 ) * -3 - 11  = -71
    val EvaluationResult(v, e) = res
    assert(v == Value(-71))
    assert(e == env4)
  }

  test("Evaluation of simple assignment operation") {
    val env = Environment.extend(Var("a"), Value(4))
    val env2 = env.extend(Var("b"), Value(5))
    val res = ExprParser.parse("c =  a / b") match {
      case ExprParseSuccess(program) =>
        Evaluator.evalProgram(program, env2)
      case ExprParseFailure(message) => fail()
      case _ => fail()
    }
    // c = 4 / 5 = 0.8
    val env3 = env2.extend(Var("c"), Value(4.0/5.0))
    //val env5 = res.env
    val EvaluationResult(v, e) = res
    assert(v == Value(4.0/5.0))
    assert(e.toString == env3.toString)
  }

  test("Evaluation of complex assignment operation") {
    val env = Environment.extend(Var("a"), Value(15))
    val env2 = env.extend(Var("b"), Value(5))
    val env3 = env2.extend(Var("c"), Value(-3))
    val env4 = env3.extend(Var("d"), Value(11))
    val res = ExprParser.parse("e =  a + b - c - d ") match {
      case ExprParseSuccess(program) =>
        Evaluator.evalProgram(program, env4)
      case ExprParseFailure(message) => fail()
      case _ => fail()
    }
    // e = 15 + 5 - -3 - 11 = 12
    val env5 = env4.extend(Var("e"), Value(12))
    //val env5 = res.env
    val EvaluationResult(v, e) = res
    assert(v == Value(12))
    assert(e.toString == env5.toString)
  }
  
  test("Evaluation of multiple assignment expression") {
    val env = Environment
    val res = ExprParser.parse("a = 39") match {
      case ExprParseSuccess(program) =>
        Evaluator.evalProgram(program, env)
      case ExprParseFailure(message) => fail()
      case _ => fail()
    }
    val env2 = res.env  
    val res2 = ExprParser.parse("b = 2") match {
      case ExprParseSuccess(program) =>
        Evaluator.evalProgram(program, env2)
      case ExprParseFailure(message) => fail()
      case _ => fail()
    }
    val env3 = res2.env  
    val res3 = ExprParser.parse("c = 65") match {
      case ExprParseSuccess(program) =>
        Evaluator.evalProgram(program, env3)
      case ExprParseFailure(message) => fail()
      case _ => fail()
    }
    val EvaluationResult(v, e) = res3
    assert(v == Value(65))
    e.lookup(Var("a")) match {
      case Some(Binding(_, v)) => assert(v == Value(39))
      case None => fail()
    }
    e.lookup(Var("b")) match {
      case Some(Binding(_, v)) => assert(v == Value(2))
      case None => fail()
    }
    e.lookup(Var("c")) match {
      case Some(Binding(_, v)) => assert(v == Value(65))
      case None => fail()
    }  
  }

  test("Evaluation of double assignment expression") {
    val env = Environment
    val res = ExprParser.parse("a = 39") match {
      case ExprParseSuccess(program) =>
        Evaluator.evalProgram(program, env)
      case ExprParseFailure(message) => fail()
      case _ => fail()
    }
    val env2 = res.env  
    val res2 = ExprParser.parse("a = 2") match {
      case ExprParseSuccess(program) =>
        Evaluator.evalProgram(program, env2)
      case ExprParseFailure(message) => fail()
      case _ => fail()
    }
    val EvaluationResult(v, e) = res2
    assert(v == Value(2))
    e.lookup(Var("a")) match {
      case Some(Binding(_, v)) => assert(v == Value(2))
      case None => fail()
    }
  }




}
