Programming Methodology
CMPSCI 220

In this project, I implemented an evaluator for expressions involving
addition, subtraction, multiplication, division, assignment, etc.
The hardest part of this project is understanding how different programs
work together to form a larger program as a whole. Also, the tests that
we are required to write were challenging because we were never taught
how to write tests. The case classes and pattern matching were
relatively easy because we have done them before in discussion. 
