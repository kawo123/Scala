package cs220.regex

object Factory {
  def re: RegExLanguage = new RegExLang
}
