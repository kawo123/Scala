package cs220.regex

/**
  * Implementation of RegExLanguage trait; returns instances of each class in my RegExClasses
  */

private[regex] class RegExLang extends RegExLanguage{

/**
  * Returns an instance of RegExEmpty
  */
  def empty: RegEx = {
    new RegExEmpty
  }

/**
  * Returns an instance of RegExChar with parameter c
  */
  def char(c: Char): RegEx = {
    new RegExChar(c)
  }

/**
  * Returns an instance of RegExSeq with two RegEx parameters
  */
  def seq(re1: RegEx, re2: RegEx): RegEx = {
    new RegExSeq(re1, re2)
  }

/**
  * Returns an instance of RegExAlt with two RegEx parameters
  */
  def alt(re1: RegEx, re2: RegEx): RegEx = {
    new RegExAlt(re1, re2)
  }

/**
  * Returns an instance of RegExSeq by calling strHelper to transform a string into Sequence
  */
  def str(s: String): RegEx = {
    val xs = s.toList
    if (xs.length == 1){
      new RegExChar(xs(0))
    }
    else{
      strHelper(xs)
    }
  }

/**
  * Helper function to str; transforms a List[Char] into Sequence recursively
  */
  def strHelper (sList: List[Char]): RegEx = {
    sList match{
      case Nil                => new RegExEmpty
      case c::cc if cc == Nil => new RegExSeq(new RegExChar(c), new RegExEmpty)
      case c::cc if cc != Nil => new RegExSeq(new RegExChar(c), strHelper(cc))
    }
  }

/**
  * Returns an instance of RegExClosure with a RegEx parameter
  */
  def closure(re: RegEx): RegEx = {
    new RegExClosure(re)
  }
}
