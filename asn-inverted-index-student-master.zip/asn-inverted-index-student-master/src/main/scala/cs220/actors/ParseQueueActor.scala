package cs220.actors

import scala.collection.mutable.Queue
import akka.actor.Actor
import akka.actor.{ActorRef, ActorLogging}

/**
 * The `ParseQueueActor` is responsible for maintaining a queue of pages
 * to be parsed by the `ParseActor`s. It is responsible for determining
 * if a page has already been parsed. If so, it should not parse it again.
 */
class ParseQueueActor(indexer: ActorRef) extends Actor with ActorLogging {
  var linkQueue: Option[ActorRef] = None
  val queue = Queue[ParsePage]()

  def receive = {

    // This message is received from LinkQueueActor (LQA) containing the url
    // and html retrieved from web. A reference to the sender is saved the
    // first time this message is received. A Checkpage message is sent to
    // the IndexActor to check if the page has already been visited in the
    // database
    case Page(url, html) => {
      if (linkQueue == None){
        linkQueue = Some(sender)
      }
      indexer ! CheckPage(url, html)
    }

    // This message is sent by the IndexActor indicating that the page is
    // safe to parse. This is in response to the CheckPage message. The
    // ParsePage message should be enqueued.
    case ParsePage(url, html) => {
      queue.enqueue(ParsePage(url, html))
    }

    // This message is sent from ParseActor (PA) to request a page to parse.
    // If the queue is not empty then a ParsePage message should be dequeued
    // and sent back to the PA. If the queue is empty then a NoPages
    // message is sent.
    case NeedPage => {
      if (queue.isEmpty){
        sender ! NoPages
      }
      else{
        sender ! queue.dequeue
      }
    }

    // This message is sent from a ParseActor (PA) containing a URL of a
    // link it parsedd from a Page. A CheckLink message is sent to the
    // IndexActor to check if the link has been visitied already.
    case Link(url) => {
      indexer ! CheckLink(url)
    }

    // This message is sent from a ParseActor containing a word that was
    // parsed from a page. This message is forwarded to the IndexActor to be
    // store in the index table in database.
    case Word(url, word) => {
      indexer ! Word(url, word)
    }

    // This message is sent from the IndexActor in response to a CheckLink
    // message. This message is forwarded to LinkQueueActor
    case QueueLink(url) => {
      linkQueue.get ! QueueLink(url)
    }
  }

}
