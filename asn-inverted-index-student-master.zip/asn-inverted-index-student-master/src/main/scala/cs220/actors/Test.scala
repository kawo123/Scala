package cs220.actors

import akka.actor.Actor
import akka.actor.{ActorRef, ActorLogging}
import scalikejdbc._
import scalaj.http._


object Test extends App{

  val html = Http("http://umass-cs-220.github.io/").param("q", "monkeys").asString.body

  println(removeHead(html))
  println("""









""")
  val d = removeComment(removeStyle(removeScript(removeHead(html))))
  println (d)
  extractLink(d).foreach(println _ )


  def removeHead (html: String): String = {
    """(?s)<head.*>.*</head>""".r.replaceAllIn(html, "")
  }

  def removeScript (html: String): String = {
    """(?s)<script.*>.*</script>""".r.replaceAllIn(html, "")
  }

  def removeStyle (html: String): String = {
    """(?s)<style.*>.*</style>""".r.replaceAllIn(html, "")
  }

  def removeComment (html: String): String = {
    """(?s)<!--.*-->""".r.replaceAllIn(html, "")
  }

  def extractLink (html: String): Iterator[String] = {
    """(https?://[^\"]+)""".r.findAllIn(html)
  }

  def trimSpaces (html: String): String = {
    """[ \t\x0B\f]+""".r.replaceAllIn(html, " ")
  } 

  def removeTag (html: String): String = {
    """</?[^>]+>""".r.replaceAllIn(html, "")
  }
 
 
}
