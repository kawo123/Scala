package cs220.actors

import scala.collection.mutable.Queue
import scala.collection.mutable.Set
import akka.actor.{Actor, ActorRef, ActorLogging}

/**
 * The `LinkQueueActor` is responsible for queuing links to be fetched by
 * a `FetchActor`. The `FetchActor` will communicate with this actor to
 * get the next link to fetch. We limit the number of links fetched to an
 * arbitrary total of 500 - after which this actor will shutdown the actor
 * system.
 */
class LinkQueueActor(parseQueue: ActorRef) extends Actor with ActorLogging {
  // We have provided some definitions below which will help you with
  // you implementation. You are welcome to modify these, however, this
  // is what we used for our implementation.
  val queue        = Queue[String]()
  val fetchers     = Set[ActorRef]()
  var limit        = 500

  def receive = {

    // This message is received from FetchActor (FA) requesting a link to be
    // fetched from the web. First, it checks if the limit on the number of
    // page processed has been reached (500). If the limit is reached the 
    // entire akka system is shutdown. Otherwise it send a FetchLink message
    // to FA if the queue is not empty or a NoLink message if it is empty
    case NeedLink =>{
      if (limit == 0){
        context.system.shutdown()
        println("Limit has reached")
      }
      else{
        if(!queue.isEmpty){
          sender ! FetchLink(queue.dequeue)
          limit = limit - 1
          println(s"$limit Page remained to be processed")
        }
        else{
          sender ! NoLinks
        }
      }
    }

    // This message is sent by FetchActor (FA) with the url and html that
    // has been received from the web. This message is then forwarded to
    // the ParseQueueActor to be queued for parsing.   
    case Page(url, html) => {
      parseQueue ! Page(url, html)
    }

    // This message is sent by ParseQueueActor indicating that the url
    // should be enqueued. The url is enqueued.
    case QueueLink(url) => {
      queue.enqueue(url)
    }
  }

}
