package cs220.actors

import akka.actor.Actor
import akka.actor.{ActorRef, ActorLogging}

/**
 * The `ParseActor` handles the parsing of HTML documents. Its
 * primary goal is to extract out the links and words contained
 * in an HTML document.
 */
class ParseActor(pq: ActorRef) extends Actor with ActorLogging {
  log.info("ParseActor created")
  pq ! NeedPage

  def receive = {

    // This message is sent from the ParseQueueActor (PQA) containing
    // the url and html retrieved from the web. Links and Words are
    // extracted from the HTML. Link and Word messages are sent to PQA
    // for each link and word extracted respectively. In the end,
    // NeedPage message is sent to PQA
    case ParsePage(url, html) => {
      val body = removeComment(removeStyle(removeScript(removeHead(html))))
      val listLink = extractLink(body)
      for (link <- listLink){
        sender ! Link(link)
      }
      val listWords = getAlphabets(trimSpaces(removeTag(body)))
      for (word <- listWords){
        sender ! Word(url, word)
      }
      sender ! NeedPage
    }

    // This message is sent from the ParseQueueActor (PQA) in response
    // to a NeedPage message indicating that the Queue is empty. The
    // response is another NeedPage message.  
    case NoPages => {
      sender ! NeedPage
    }
  }

  // This function takes in a string HTML and returns a string HTML
  // without the head tag and its content.
  def removeHead (html: String): String = {
    """(?s)<head.*>.*</head>""".r.replaceAllIn(html, "")
  }

  // This function takes in a string HTML and returns a string HTML
  // without the script tag and its content. 
  def removeScript (html: String): String = {
    """(?s)<script.*>.*</script>""".r.replaceAllIn(html, "")
  }

  // This function takes in a string HTML and returns a string HTML
  // without the style tag and its content.
  def removeStyle (html: String): String = {
    """(?s)<style.*>.*</style>""".r.replaceAllIn(html, "")
  }

  // This function takes in a string HTML and returns a string HTML
  // without the comment tag and its content.
  def removeComment (html: String): String = {
    """(?s)<!--.*-->""".r.replaceAllIn(html, "")
  }

  // This function takes in a string HTML and returns Iterator[String]
  // of the links that are in this HTML
  def extractLink (html: String): Iterator[String] = {
    """(https?://[^\"]+)""".r.findAllIn(html)
  }

  // This function takes in a string HTML and returns a string HTML
  // without the extra spacing. 
  def trimSpaces (html: String): String = {
    """[ \t\x0B\f]+""".r.replaceAllIn(html, " ")
  } 

  // This function takes in a string HTML and returns a string HTML
  // without any tags.
  def removeTag (html: String): String = {
    """</?[^>]+>""".r.replaceAllIn(html, "")
  }

  // This function takes in a string HTML and returns Iterator[String]
  // of all the words that has valid alphabets.
  def getAlphabets (html: String): Iterator[String] = {
    """[a-zA-Z]+""".r.findAllIn(html)
  }
}
