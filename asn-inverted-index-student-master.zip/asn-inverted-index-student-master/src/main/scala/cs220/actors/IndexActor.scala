package cs220.actors

import scalikejdbc._
import akka.actor.{Actor, ActorLogging}

/**
 * The `IndexActor` is responsible for communicating with the
 * database to index a word.
 */
class IndexActor extends Actor with ActorLogging {

  def receive = {

    // This message is received from the ParseQueueActor (PQA) to
    // determine if we have seen this url using SQL and database.
    // If we have not, we would insert this url into the Document table
    // and respond with a ParsePage message back to PQA. No response if
    // we have seen it url before. 
    case CheckPage(url, html) => {
      val flag: Option[docRow] = checkUrl(url)
      flag match {
        case None => {
          sql"""
             insert into documents(url) values ($url) 
          """.update.apply()
          sender ! ParsePage(url, html)
        }
        case _    =>
      }
    }

    // This message is sent by the ParseQueueActor (PQA) to determine
    // if we have already seen this url. If we have, no response is
    // necessary. If not, a QueueLink message is sent back to PQA which
    // will then forward the message to LinkQueueActor
    case CheckLink(url) => {
      val flag: Option[docRow] = checkUrl(url)
      flag match {
        case None => sender ! QueueLink(url)
        case _    =>
      }
    }

    // This message is received from the ParseQueueActgor(PQA) to
    // indicate that this word needs to be indexed in the database.
    // The word is inserted into the Index table with proper ID's.   
    case Word(url, word) => {
      val doc = checkUrl(url)
      /*      val doc = sql"""
                  select *
                  from documents
                  where url = $url
                """.map(
                  xs => new docRow(xs.int("docid"),
                                   xs.string("url"))
                ).single.apply()
 */
      var words: Option[wordRow] = checkWord(word)
      
      words match {
        case None => {
          sql"""
            insert into words(word) values ($word)
          """.update.apply()
          words = checkWord(word)
        }
        case _ => 
      }
      val docid = doc.get.docid
      val wordid = words.get.wordid
      sql"""
        insert into index values ($wordid, $docid)
      """.update.apply()
    }
  }

  // This function checks if the URL is in the Document table and returns
  // an Option[docRow]. docRow is declared at the end of the program. 
  def checkUrl(url: String): Option[docRow] = {
    sql"""
      select *
      from documents
      where url = $url
    """.map(
      xs => new docRow(xs.int("docid"),
                       xs.string("url"))
    ).single.apply()
  }

  // This function checks if the URL is in the Word table and returns
  // an Option[wordRow]. wordRow is declared at the end of the program. 
  def checkWord(word: String): Option[wordRow] = {
    sql"""
      select *
      from words
      where word = $word
    """.map(
      xs => new wordRow(xs.int("wordid"),
                       xs.string("word"))
    ).single.apply()
  }

  ///////////////////////////////////////////////////////////////////
  // The code below is a starting point for your queries/updates to
  // the database. We have provided the database creation SQL for
  // you. You will not need to add any additional tables. Your goal
  // is to populate it with data you have received from parsed HTML
  // documents. We strongly suggest that you implement each of your
  // queries as individual methods in this class, where each method
  // corresponds to some query that is useful in building the index.
  ///////////////////////////////////////////////////////////////////

  // Necessary setup for connecting to the H2 database:
  Class.forName("org.h2.Driver")
  ConnectionPool.singleton("jdbc:h2:./indexer", "sa", "")
  implicit val session = AutoSession

  // Create the database when this object is referenced.
  createDatabase

  def createDatabase: Unit = {
    sql"""
      drop table words if exists;
      drop table documents if exists;
      drop table index if exists;
    """.update.apply()

    // Create the tables if they do not already exist:
    sql"""
    create table if not exists words (
      wordid int auto_increment,
      word varchar(50),
      primary key (wordid)
    );
    """.update.apply()

    sql"""
    create table if not exists documents (
      docid int auto_increment,
      url varchar(1024),
      primary key (docid)
    );
    """.update.apply()

    sql"""
    create table if not exists index (
      wordid int,
      docid int,
      foreign key (wordid) references words (wordid) on delete cascade,
      foreign key (docid) references documents (docid) on delete cascade
    );
    """.update.apply()
  }

}

// Case classes for storing the docid and URL
case class docRow(docid: Int, url: String)

// Case classes for storing wordid and word
case class wordRow(wordid: Int, word: String)
