CMPSCI 220 Programming Methodology
Project Assignment 02

This assignment focuses on implementing functions that can be used to access
a .csv file. The .csv file provided by the instructor contains information
about different brands of cereals. The maxCalories and minCalories are the
hardest functions to implement because they incorporate two other functions
into themselves. In order to reduce redundancy of code, I made my own helper
function findExtreme. The easiest part of this assignment was implementing
the first four functions (nrows, ncols, rows, and headers) beacuse they are
easy and straight forward. The three additional methods that I implemented in
CerealCsv are minSugar, maxSugar, and countMfrK. minSugar and maxSugar finds
minimum sugar cereal and maximum sugar cereal respectively. countMfrK finds
the count of K under header mfr and returns a list of those rows.
