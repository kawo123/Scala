package cs220.ds

import scala.io.Source

class CerealCsv (val hs: List[String], val ds: List[List[String]]) extends CerealCsvTrait{

  //Returns the number of rows in the CSV data (excluding header)
  def nrows(): Int = ds.length

  //Returns the number of columns in CSV data
  def ncols(): Int = hs.length

  //Returns the rows in the CSV file as a list of list of strings
  def rows(): List[List[String]] = ds

  //Returns a list of header names in CSV file
  def headers(): List[String] = hs

  //Returns a list of the row data with the given index
  def row(idx: Int) : List[String] = ds(idx) 

  //Returns a pair containing the header name and the list of the
  //data in a column under that header. The return pair will
  //contain empty list if the header name does not exist.
  def column (hname: String): (String, List[String]) = {
    val index = hs.indexOf(hname)
    if (index != -1){
      val colList =
        for {
          row <- ds
          col = row(index)
        }yield col
      (hname, colList)
    }
    else
      (hname, List())
  }

  //Returns the rows that match the given value in a row with the
  //given header name. Empty list will be returned if there is no
  //match
  def rowMatch(hname:String,value:String): List[List[String]] = {
    val index = hs.indexOf(hname)
    if (index != -1){
      val matchList =
        for {
          row <- ds if (row(index) == value)
          col = row
        }yield col
       matchList
    }
    else
      List(List())
  }

  //Converts a list of rows into a String in CSV format
  def toCSV(xss: List[List[String]]): String = {
    if (xss.length == 0) 
      ""
    else
      xss.head.mkString(",") + "\n" + toCSV(xss.tail)

  }

  def minCalories(): List[List[String]] = {
    //Finding cereal with minimum calories 
    //I was going to use my findExtreme helper method but the
    //rubric said to incorporate the use of column and rowMatch
    //in the method
 
    val colList = column("calories")._2
    val data =
      for {
        calories <- colList
        caloriesList = calories.toInt
      }yield caloriesList
    val list = data.sorted.head.toString
    rowMatch("calories", list)
    
  }

  def maxCalories(): List[List[String]] = {
    //Finding cereal with maximum calories 
    //I was going to use my findExtreme helper method but the
    //rubric said to incorporate the use of column and rowMatch
    //in the method
    val colList = column("calories")._2
    val data =
      for {
        calories <- colList
        caloriesList = calories.toInt
      }yield caloriesList
    val list = data.sorted.reverse.head.toString
    rowMatch("calories", list) 
  }

  def minSugar(): List[List[String]] = {
    //Finding cereal with minimum sugar contents using findExtreme helper
    //method
    findExtreme("sugars", 0)
  }

  def maxSugar(): List[List[String]] = {
    //Finding cereal with maximum sugar contents using findExtreme helper
    //method
    findExtreme("sugars", 1)
  }

  // Return the number of K under header mfr and list of list of strings
  // of occurance. We return multiple rows because there may be more than
  // one occurance. This is actually quite difficult because I need to do
  // some outside research on scala syntax. 
  def countMfrK (): (Int,List[List[String]]) ={
    val colList = column("mfr")._2
    val count = colList.count( _ == "K" )
    (count, rowMatch("mfr", "K"))
  }

  private def findExtreme(hname: String, indicator: Int): List[List[String]] = {
    //The value 1 is an indicator that we are looking for the max element in
    //a column while 0 indicates that we are looking for the min element.
    //val min = 0 is never initialized because it is not used directly in the
    //code. 
    val max = 1
    val colList = column(hname)._2
    val data =
      for {
        col <- colList
        finalList = col.toInt
      }yield finalList
    if (indicator == max){
      val list = data.sorted.reverse.head.toString
      rowMatch(hname,list)
    }
    else {
      val list = data.sorted.head.toString
      rowMatch(hname, list)
    }
  }

}

object CerealCsv extends CsvReader[CerealCsvTrait]{

  //Returns an instance of CerealCsv with information of the given .csv file
  def read (file:String): CerealCsvTrait = {
    val lines = Source.fromFile(file).getLines.toList
    val header = lines.head
    val headerList = header.split(",").toList
    val data  =
      for {
        line<-lines.tail
        row = line.split(",").toList
      } yield row
    new CerealCsv (headerList, data)
  }
}
