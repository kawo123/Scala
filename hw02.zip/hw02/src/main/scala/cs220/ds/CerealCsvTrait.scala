package cs220.ds

trait CerealCsvTrait extends CsvData{
  // Returns the rows containing the minimum calorie cereals. We
  // return multiple rows because we may have mulitple cereals with
  // the same minimum calories.
  def minCalories(): List[List[String]]

  // Returns the rows containing the maximum calorie cereals. We
  // return mulitple rows because we may have multiple cereals with
  // the same maximum calories
  def maxCalories(): List[List[String]]

  // Returns the rows containing the minimum sugar cereals. We
  // return mulitple rows because we may have multiple cereals with
  // the same maximum calories
  def minSugar(): List[List[String]]

  // Returns the rows containing the maximum sugar cereals. We
  // return mulitple rows because we may have multiple cereals with
  // the same maximum calories
  def maxSugar(): List[List[String]]

  //Return the number of K under header mfr and the List of those
  //List of String as a pair
  def countMfrK (): (Int,List[List[String]])
}
