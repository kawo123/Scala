java -cp bin $1
