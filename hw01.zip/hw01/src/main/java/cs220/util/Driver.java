package cs220.util; 

public class Driver
{
    public static void main (String [] args)
    {
	String[] arr = {"Hello", "World"};
	Function<String> println = Util.println();
	ScalaArray<String> array = Util.scalaArray(arr);
	array.foreach(println); 
    }
}
