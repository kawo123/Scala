package cs220.util;

public class Util
{
    public static <T> ScalaArray<T> scalaArray (T[] jarray)
    {
	//TODO: Return an instance of your ScalaArray.
	return new Array<T>(jarray);
    }

    public static <T> Function<T> println()
    {
	//TODO: Return an instance of a println function. 
	return new Println<T> (); 
    }
}
