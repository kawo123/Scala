package cs220.util;

public interface Function<T> {

    public void apply(T arg);    
}
