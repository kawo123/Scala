package cs220.util;

public class Println<T> implements Function<T>
{

    public Println () {}

    public void apply (T arg)
    {
	System.out.println(arg); 
    }
}
