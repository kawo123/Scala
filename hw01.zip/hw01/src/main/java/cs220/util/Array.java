package cs220.util;

public class Array<T> implements ScalaArray<T>
{

    private T[] scalaArray;
    
    public Array(T[] array1)
    {
	scalaArray = array1; 
    }

    public void foreach(Function<T> fn)
    {
	//Iterating through the array for the foreach effect
	for (int i = 0; i < scalaArray.length; i++)
	    fn.apply(scalaArray[i]);
    }
	
}
