  CMPSCI 220 Programming Methodology
 Project Assignment 01
 Ka Wo Fong
 28761730
