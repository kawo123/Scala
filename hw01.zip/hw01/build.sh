rm -rf bin/*
javac -d ./bin src/main/java/cs220/util/*
